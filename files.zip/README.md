# Grandview Hotel Website

A responsive, multi-page static website built for the **MANTRA 2026 Summer School — Frontend Website Assignment**.

## 📌 Topic
Hotel Website — **Grandview Hotel**

## 🛠️ Tools & Technologies
- HTML5
- CSS3 (Flexbox, Grid, Media Queries)
- JavaScript (Vanilla JS)
- GitHub (code hosting)
- Netlify (deployment)

## 📄 Pages
| Page | File | Description |
|------|------|--------------|
| Home | `index.html` | Banner, introduction, featured rooms, why-choose-us, FAQ |
| About | `about.html` | Hotel history, stats, and values |
| Rooms | `rooms.html` | Room categories, pricing, and facilities |
| Gallery | `gallery.html` | Photos with captions and alt text |
| Contact | `contact.html` | Contact details, map, and booking enquiry form |

## ✨ Features
- Fully responsive design for mobile, tablet, and desktop (CSS media queries)
- Mobile hamburger navigation menu
- FAQ accordion toggle (JavaScript)
- Booking form with client-side validation (name, email, phone, message)
- Embedded Google Map on the Contact page
- Basic on-page SEO: unique `<title>` tags, meta description, meta keywords, single `<h1>` per page, descriptive alt text on all images

## 🚀 Deployment
1. Push this project to a public GitHub repository.
2. Connect the repository to Netlify (or drag-and-drop the folder into Netlify).
3. Set the publish directory to the project root.
4. Deploy and verify the live link opens correctly.

## 📋 SEO Checklist
- [x] Title tag on every page
- [x] Meta description and meta keywords on every page
- [x] One `<h1>` per page
- [x] `<h2>` / `<h3>` for section headings
- [x] Meaningful alt text on all images
- [x] Simple file names (about.html, rooms.html, gallery.html, contact.html)

## 👤 Author
Student Name: _____________________
Registration / Roll Number: _____________________
