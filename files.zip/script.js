/* ===== Grandview Hotel - Main JavaScript ===== */

// ----- Mobile Menu Toggle -----
document.addEventListener("DOMContentLoaded", function () {
  var menuToggle = document.querySelector(".menu-toggle");
  var navLinks = document.querySelector(".nav-links");

  if (menuToggle && navLinks) {
    menuToggle.addEventListener("click", function () {
      navLinks.classList.toggle("show");
    });
  }

  // ----- FAQ Toggle (used on Rooms / Home page) -----
  var faqItems = document.querySelectorAll(".faq-item");
  faqItems.forEach(function (item) {
    var question = item.querySelector(".faq-question");
    if (question) {
      question.addEventListener("click", function () {
        item.classList.toggle("open");
      });
    }
  });

  // ----- Booking / Contact Form Validation -----
  var bookingForm = document.getElementById("bookingForm");
  if (bookingForm) {
    bookingForm.addEventListener("submit", function (e) {
      e.preventDefault();
      var isValid = true;

      var name = document.getElementById("name");
      var email = document.getElementById("email");
      var phone = document.getElementById("phone");
      var message = document.getElementById("message");

      function showError(input, errorId, condition) {
        var errorEl = document.getElementById(errorId);
        if (condition) {
          errorEl.style.display = "block";
          isValid = false;
        } else {
          errorEl.style.display = "none";
        }
      }

      showError(name, "nameError", name.value.trim() === "");

      var emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      showError(email, "emailError", !emailPattern.test(email.value.trim()));

      var phonePattern = /^[0-9]{10}$/;
      showError(phone, "phoneError", !phonePattern.test(phone.value.trim()));

      showError(message, "messageError", message.value.trim().length < 5);

      var successMsg = document.getElementById("formSuccess");

      if (isValid) {
        successMsg.style.display = "block";
        successMsg.textContent =
          "Thank you! Your booking enquiry has been received. Our team will contact you shortly.";
        bookingForm.reset();
      } else {
        successMsg.style.display = "none";
      }
    });
  }
});
